Project Name: Original XBOX HDMI Board v1
Project Version: #4de7e018
Project Url: https://www.flux.ai/techengineered/original-xbox-hdmi-board-v1

Project Description:
Original XBOX HDMI Board to replace AV port and output HDMI signal


